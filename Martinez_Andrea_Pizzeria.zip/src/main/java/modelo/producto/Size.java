package modelo.producto;

public enum Size {
   GRANDE ,MEDIANA, PEQUEÑA
}
