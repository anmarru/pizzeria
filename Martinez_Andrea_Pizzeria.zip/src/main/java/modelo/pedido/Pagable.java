package modelo.pedido;

public interface  Pagable {
    
    public void pagar(double cantidad);
    
    
}
