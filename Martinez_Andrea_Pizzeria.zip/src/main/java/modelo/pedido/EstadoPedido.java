package modelo.pedido;

public enum EstadoPedido {

    PENDIENTE,ENTREGADO, PAGADO, CANCELADO
}
